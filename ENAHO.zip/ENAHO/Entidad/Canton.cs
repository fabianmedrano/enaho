﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
   public class Canton
    {
        #region "Atributos"
        public String CanNomCanton { get; set; } //Nombre de
        public Int32 CanIDCanton { get; set; } //ID del cantón
        #endregion
        #region Constructor
        public Canton() { }
        #endregion

    }
}

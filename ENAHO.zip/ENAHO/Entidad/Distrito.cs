﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class Distrito
    {
        public String DisNomDistrito { get; set; } //Nombre del distrito
        public Int32 DisIDDistrito { get; set; } //ID del distrito
        #region Constructor
        public Distrito() { }
        #endregion
    }
}

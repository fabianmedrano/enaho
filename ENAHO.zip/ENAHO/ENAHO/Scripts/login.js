﻿
$(document).ready(function () {
   
    $("#tb_usuario").keydown(function () {
        $("#l_login").hide();
    }); 
    $("#tb_pass").keydown(function () {
        $("#l_login").hide();
    });
   
  

});